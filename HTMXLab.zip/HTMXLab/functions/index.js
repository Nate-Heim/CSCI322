const functions = require("firebase-functions");
const express = require("express");
const pug = require("pug");

const app = express(); // 1. Create Express app

// 2. Define route to handle GET /card
app.get("/card", (req, res) => {
  const { name, major, quote } = req.query;

  // 3. Render the Pug template with the query data
  const html = pug.renderFile(__dirname + "/views/test.pug", {
    name,
    major,
    quote
  });

  res.send(html); // 4. Send rendered HTML
});

// 5. Export the Express app as a Firebase Function
exports.app = functions.https.onRequest(app);